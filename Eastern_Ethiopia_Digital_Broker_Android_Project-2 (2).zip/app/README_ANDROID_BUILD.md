# Eastern Ethiopia Digital Broker - Android Build

## Project type
Capacitor Android wrapper around the included production-ready web application.

## Requirements
- Node.js 20+
- Android Studio with Android SDK
- JDK 17+

## Build steps
1. Open a terminal in this folder.
2. Run: `npm install`
3. Run: `npx cap add android`
4. Run: `npx cap sync android`
5. Open `android/` in Android Studio.
6. Test on an emulator or physical Android device.
7. Build APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
8. Build signed AAB: Build > Generate Signed Bundle / APK > Android App Bundle.

## Package
`com.eedb.digitalbroker`

## Before release
- Run the included Supabase SQL fixes as documented in `FINAL_REBUILD_NOTES.txt`.
- Test authentication, properties, jobs, applications, admin roles, and location flows.
- Create a release signing key and keep it securely backed up.
- Increment versionCode/versionName before Play Store updates.
